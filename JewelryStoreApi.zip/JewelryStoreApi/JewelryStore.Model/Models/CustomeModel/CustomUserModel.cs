﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelryStore.Model
{
    public class CustomUserModel
    {
        public string UserName { get; set; }

        public int UserType { get; set; }
    }
}

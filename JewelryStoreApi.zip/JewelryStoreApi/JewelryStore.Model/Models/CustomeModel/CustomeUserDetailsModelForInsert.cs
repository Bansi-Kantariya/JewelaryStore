﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelryStore.Model
{
    public class CustomeUserDetailsModelForInsert
    {
        public string UserName { get; set; }

        public string Password { get; set; }

        public int UserType { get; set; }
    }
}
